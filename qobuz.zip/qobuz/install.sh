#!/bin/bash

echo "Installing Qobuz Dependencies"

#requred to end the plugin install
echo "plugininstallend"
